import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  ChevronDown, 
  ChevronRight, 
  Calendar, 
  University, 
  CreditCard, 
  Trash2,
  DollarSign
} from "lucide-react";
import NavigationMenu from "@/components/navigation-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Card as CardType, Purchase } from "@shared/schema";

interface InvoiceData {
  month: string;
  totalValue: number;
  cardId: string;
  card: CardType;
}

interface YearGroup {
  year: string;
  months: MonthGroup[];
}

interface MonthGroup {
  month: string;
  monthName: string;
  totalMonth: number;
  invoices: InvoiceData[];
  purchases: (Purchase & { card: CardType })[];
}

export default function InvoiceHistoryPage() {
  const [openYears, setOpenYears] = useState<Set<string>>(new Set());
  const [openMonths, setOpenMonths] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: allPurchases = [], isLoading } = useQuery<(Purchase & { card: CardType })[]>({
    queryKey: ["/api/purchases"],
  });

  const toggleYear = (year: string) => {
    const newOpenYears = new Set(openYears);
    if (newOpenYears.has(year)) {
      newOpenYears.delete(year);
    } else {
      newOpenYears.add(year);
    }
    setOpenYears(newOpenYears);
  };

  const toggleMonth = (month: string) => {
    const newOpenMonths = new Set(openMonths);
    if (newOpenMonths.has(month)) {
      newOpenMonths.delete(month);
    } else {
      newOpenMonths.add(month);
    }
    setOpenMonths(newOpenMonths);
  };

  // Group purchases by year and month
  const groupedData: YearGroup[] = (() => {
    const yearMap = new Map<string, Map<string, { purchases: (Purchase & { card: CardType })[], invoices: Map<string, InvoiceData> }>>();

    // Group by year and month
    allPurchases.forEach(purchase => {
      const year = purchase.invoiceMonth.split('-')[0];
      const month = purchase.invoiceMonth;

      if (!yearMap.has(year)) {
        yearMap.set(year, new Map());
      }

      const yearData = yearMap.get(year)!;
      if (!yearData.has(month)) {
        yearData.set(month, { purchases: [], invoices: new Map() });
      }

      const monthData = yearData.get(month)!;
      monthData.purchases.push(purchase);

      // Group by card for invoice totals
      const cardId = purchase.card.id;
      if (!monthData.invoices.has(cardId)) {
        monthData.invoices.set(cardId, {
          month,
          totalValue: 0,
          cardId,
          card: purchase.card
        });
      }
      monthData.invoices.get(cardId)!.totalValue += parseFloat(purchase.installmentValue);
    });

    // Convert to array format
    return Array.from(yearMap.entries())
      .map(([year, monthsMap]) => ({
        year,
        months: Array.from(monthsMap.entries())
          .map(([month, data]) => {
            const invoices = Array.from(data.invoices.values());
            const totalMonth = invoices.reduce((sum, inv) => sum + inv.totalValue, 0);
            
            return {
              month,
              monthName: format(new Date(month + "-01"), "MMMM yyyy", { locale: ptBR }),
              totalMonth,
              invoices,
              purchases: data.purchases
            };
          })
          .sort((a, b) => b.month.localeCompare(a.month)) // Most recent months first
      }))
      .sort((a, b) => b.year.localeCompare(a.year)); // Most recent years first
  })();

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      alimentacao: "bg-gray-100 text-gray-600",
      eletronicos: "bg-blue-100 text-blue-600",
      combustivel: "bg-green-100 text-green-600",
      vestuario: "bg-purple-100 text-purple-600",
      saude: "bg-red-100 text-red-600",
      outros: "bg-orange-100 text-orange-600",
    };
    return colors[category] || "bg-gray-100 text-gray-600";
  };

  const categoryLabels: Record<string, string> = {
    alimentacao: "Alimentação",
    eletronicos: "Eletrônicos",
    combustivel: "Combustível",
    vestuario: "Vestuário",
    saude: "Saúde",
    outros: "Outros",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-white hover:bg-white hover:bg-opacity-20">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <h1 className="text-xl font-medium">Histórico de Faturas</h1>
            </div>
            <NavigationMenu />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-6xl">
        <Card className="shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-medium text-secondary">
                Histórico Completo de Faturas
              </h2>
            </div>

            {isLoading ? (
              <div className="text-center py-8 text-gray-500">
                Carregando histórico...
              </div>
            ) : groupedData.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-lg mb-2">Nenhum histórico encontrado</p>
                <p className="text-sm">Registre algumas compras para ver o histórico de faturas.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {groupedData.map((yearGroup) => (
                  <Card key={yearGroup.year} className="border border-gray-200">
                    <Collapsible 
                      open={openYears.has(yearGroup.year)} 
                      onOpenChange={() => toggleYear(yearGroup.year)}
                    >
                      <CollapsibleTrigger asChild>
                        <CardContent className="p-4 cursor-pointer hover:bg-gray-50 transition-colors">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {openYears.has(yearGroup.year) ? (
                                <ChevronDown className="h-5 w-5 text-gray-500" />
                              ) : (
                                <ChevronRight className="h-5 w-5 text-gray-500" />
                              )}
                              <h3 className="text-xl font-semibold text-secondary">
                                {yearGroup.year}
                              </h3>
                            </div>
                            <Badge variant="outline" className="text-lg px-3 py-1">
                              {yearGroup.months.length} {yearGroup.months.length === 1 ? 'mês' : 'meses'}
                            </Badge>
                          </div>
                        </CardContent>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="px-4 pb-4 space-y-3">
                          {yearGroup.months.map((monthGroup) => (
                            <Card key={monthGroup.month} className="border border-gray-100 ml-4">
                              <Collapsible 
                                open={openMonths.has(monthGroup.month)} 
                                onOpenChange={() => toggleMonth(monthGroup.month)}
                              >
                                <CollapsibleTrigger asChild>
                                  <CardContent className="p-3 cursor-pointer hover:bg-gray-50 transition-colors">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-3">
                                        {openMonths.has(monthGroup.month) ? (
                                          <ChevronDown className="h-4 w-4 text-gray-500" />
                                        ) : (
                                          <ChevronRight className="h-4 w-4 text-gray-500" />
                                        )}
                                        <h4 className="text-lg font-medium text-secondary capitalize">
                                          {monthGroup.monthName}
                                        </h4>
                                      </div>
                                      <div className="text-right">
                                        <div className="text-lg font-bold text-primary">
                                          {new Intl.NumberFormat("pt-BR", {
                                            style: "currency",
                                            currency: "BRL",
                                          }).format(monthGroup.totalMonth)}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                          {monthGroup.purchases.length} compras
                                        </div>
                                      </div>
                                    </div>
                                  </CardContent>
                                </CollapsibleTrigger>
                                
                                <CollapsibleContent>
                                  <div className="px-3 pb-3 space-y-4">
                                    {/* Invoice totals by bank */}
                                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                                      {monthGroup.invoices.map((invoice) => (
                                        <Card key={invoice.cardId} className="border-l-4 border-primary bg-gray-50">
                                          <CardContent className="p-3">
                                            <div className="flex items-center justify-between">
                                              <div className="flex items-center gap-2">
                                                <University className="h-4 w-4 text-primary" />
                                                <span className="font-medium text-sm">
                                                  {invoice.card.bankName}
                                                </span>
                                              </div>
                                              <div className="text-right">
                                                <div className="font-bold text-primary">
                                                  {new Intl.NumberFormat("pt-BR", {
                                                    style: "currency",
                                                    currency: "BRL",
                                                  }).format(invoice.totalValue)}
                                                </div>
                                                <div className="text-xs text-gray-500">
                                                  Venc: {invoice.card.dueDay}/{format(new Date(monthGroup.month + "-01"), "MM/yyyy")}
                                                </div>
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>
                                      ))}
                                    </div>

                                    {/* Purchase list */}
                                    <div className="space-y-2">
                                      <h5 className="text-sm font-medium text-gray-600 flex items-center gap-2">
                                        <DollarSign className="h-4 w-4" />
                                        Compras do Mês
                                      </h5>
                                      {monthGroup.purchases.map((purchase) => (
                                        <Card key={purchase.id} className="border border-gray-100">
                                          <CardContent className="p-3">
                                            <div className="flex items-start justify-between text-sm">
                                              <div className="flex-1">
                                                <div className="flex items-center gap-2 mb-1">
                                                  <span className="font-medium">{purchase.name}</span>
                                                  <Badge className={getCategoryColor(purchase.category)} variant="secondary">
                                                    {categoryLabels[purchase.category] || purchase.category}
                                                  </Badge>
                                                </div>
                                                <div className="flex items-center gap-4 text-xs text-gray-500">
                                                  <span>{format(new Date(purchase.purchaseDate), "dd/MM/yyyy")}</span>
                                                  <span>{purchase.card.bankName}</span>
                                                  <span>{purchase.currentInstallment}/{purchase.totalInstallments}x</span>
                                                </div>
                                              </div>
                                              <div className="text-right">
                                                <div className="font-bold">
                                                  {new Intl.NumberFormat("pt-BR", {
                                                    style: "currency",
                                                    currency: "BRL",
                                                  }).format(parseFloat(purchase.installmentValue))}
                                                </div>
                                                <div className="text-xs text-gray-500">
                                                  Total: {new Intl.NumberFormat("pt-BR", {
                                                    style: "currency",
                                                    currency: "BRL",
                                                  }).format(parseFloat(purchase.totalValue))}
                                                </div>
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>
                                      ))}
                                    </div>
                                  </div>
                                </CollapsibleContent>
                              </Collapsible>
                            </Card>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}