/**
 * Calculates the invoice month for a purchase based on the purchase date and card closing day
 */
export function calculateInvoiceMonth(purchaseDate: Date, closingDay: number): string {
  const purchaseDay = purchaseDate.getDate();
  
  let invoiceDate = new Date(purchaseDate);
  
  // If purchase is on or after closing day, invoice goes to next month
  if (purchaseDay >= closingDay) {
    invoiceDate.setMonth(invoiceDate.getMonth() + 1);
  }
  
  return `${invoiceDate.getFullYear()}-${String(invoiceDate.getMonth() + 1).padStart(2, '0')}`;
}

/**
 * Calculates the installment value for a purchase
 */
export function calculateInstallmentValue(totalValue: number, totalInstallments: number): number {
  return totalValue / totalInstallments;
}

/**
 * Gets the due date for a card invoice in a given month
 */
export function getInvoiceDueDate(month: string, dueDay: number): Date {
  const [year, monthNumber] = month.split('-').map(Number);
  return new Date(year, monthNumber - 1, dueDay);
}

/**
 * Formats a month string (YYYY-MM) to a readable format
 */
export function formatMonth(month: string, locale: string = 'pt-BR'): string {
  const [year, monthNumber] = month.split('-').map(Number);
  const date = new Date(year, monthNumber - 1, 1);
  
  return date.toLocaleDateString(locale, { 
    year: 'numeric', 
    month: 'long' 
  });
}
